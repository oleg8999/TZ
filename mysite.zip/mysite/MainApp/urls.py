from django.urls import path

from . import views

app_name = 'MainApp'
urlpatterns = [
    path('', views.index, name = 'index'),
    path('<int:data_id>/', views.detail, name = 'detail'),
    path('<int:data_id>/change_data/', views.change_data, name = 'change_data')


]