from django.shortcuts import render
from django.http import Http404, HttpResponseRedirect
from django.contrib.auth.models import User

from .models import Data
from django.urls import reverse
def index (request) :
    current_data = Data.objects.all()
    return render(request, 'MainApp/List.html', {'current_data': current_data})

def detail(request, data_id):
    try:
        a = Data.objects.get(id = data_id)
    except:
        raise Http404("Данных нет")

    return render(request, 'MainApp/detail.html', {'data': a})

def change_data(request, data_id):
    try:
        a = Data.objects.get(id = data_id)
    except:
        raise Http404("Данных нет")
    if request.user.is_superuser:
        Data.objects.filter(id = data_id).update(status = request.POST.get('status'),
                                                 grade = request.POST.get('grade'),
                                                 speciality = request.POST.get('speciality'),
                                                 salary = request.POST.get('salary'),
                                                 education = request.POST.get('education'),
                                                 experience = request.POST.get('experience'),
                                                 portfolio = request.POST.get('portfolio'),
                                                 title = request.POST.get('title'),
                                                 phone = request.POST.get('phone'),
                                                 email = request.POST.get('email'))
    else:
        raise Http404("Вы не суперпользователь")

    return HttpResponseRedirect (reverse('MainApp:detail', args=(a.id,)))