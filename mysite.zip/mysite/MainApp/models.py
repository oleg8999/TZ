from django.db import models

class Data(models.Model):
    status = models.IntegerField(max_length=200)
    grade = models.IntegerField(max_length=200)
    speciality = models.CharField(max_length=200)
    salary = models.IntegerField(max_length=200)
    education = models.CharField(max_length=200)
    experience = models.IntegerField(max_length=200)
    portfolio = models.CharField(max_length=200)
    title = models.CharField(max_length=200)
    phone = models.IntegerField(max_length=200)
    email = models.CharField(max_length=200)

    def __str__(self):
        fields = (
            self.status,
            self.grade,
            self.speciality,
            self.salary,
            self.education,
            self.experience,
            self.portfolio,
            self.title,
            self.phone,
            self.email,
        )
        return '/n'.join(map(str, fields))
