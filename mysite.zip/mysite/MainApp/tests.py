from rest_framework.test import APITestCase
from MainApp.models import Data

class DataTest(APITestCase):
    def test_get(self):
        Data.objects.create(status=1, grade=5, speciality="Программист",
                            salary=35000, education=5,experience=2,
                            portfolio="Пока что нет", title="Олег",
                            phone=8906, email="oleg@gg")
    def test_patch(self):
        Data.objects.filter(id=1).update(status=1, grade=5, speciality="Программист",
                            salary="нету", education=5,experience=2,
                            portfolio="Пока что нет", title="Олег",
                            phone=8906, email="oleg@gg")
